import 'package:flutter/material.dart';

class Vehiculo extends StatelessWidget {
  const Vehiculo({super.key});

  @override
  Widget build(BuildContext context) {
    // Get the device screen size
    final screenSize = MediaQuery.of(context).size;

    // Calculate scaling factors based on design dimensions (320x568)
    final horizontalScale = screenSize.width / 320.0;
    final verticalScale = screenSize.height / 568.0;

    final _scrollController_component_1749674298760 = ScrollController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Vehiculo'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Navigation',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
              ListTile(
                leading: Icon(Icons.screen_share),
                title: Text('Compras'),
                onTap: () {
                  Navigator.pushNamed(context, '/compras');
                },
              ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: screenSize.width,
          height: screenSize.height - AppBar().preferredSize.height - MediaQuery.of(context).padding.top,
          child: Stack(
            children: [
            Positioned(
              left: 18.0 * horizontalScale,
              top: 27.0 * verticalScale,
              child:               Container(
                width: 280.0 * horizontalScale,
                height: 460.0 * verticalScale,
                padding: const EdgeInsets.all(10.0),
                decoration: BoxDecoration(
                  color: Color(0xFFE8A6A6),
                  borderRadius: BorderRadius.circular(41.0),
                  border: Border.all(
                    color: Colors.blue,
                    width: 1.0,
                    style: BorderStyle.solid,
                  ),
                ),
                child: null,
              ),
            ),
            Positioned(
              left: 49.77777099609375 * horizontalScale,
              top: 38.885414123535156 * verticalScale,
              child:               Container(
                width: 200.0 * horizontalScale,
                height: 50.0 * verticalScale,
                color: Colors.transparent,
                alignment: Alignment.center,
                child:                   Text(
                    'FORMULARIO',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 32.0,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFFE011B),
                    ),
                  ),
              ),
            ),
            Positioned(
              left: 42.0 * horizontalScale,
              top: 88.55207824707031 * verticalScale,
              child:               Container(
                width: 200.0 * horizontalScale,
                height: 50.0 * verticalScale,
                color: Colors.transparent,
                alignment: Alignment.center,
                child:                   Text(
                    'Cual es tu color favorito??',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFE4FE86),
                    ),
                  ),
              ),
            ),
            Positioned(
              left: 79.0 * horizontalScale,
              top: 145.5520782470703 * verticalScale,
              child:               Container(
                width: 150.0 * horizontalScale,
                height: 100.0 * verticalScale,
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Color(0xFFEEF6F5),
                  borderRadius: BorderRadius.circular(8.0),
                  border: Border.all(color: Colors.grey.shade300, width: 0.5),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: 16.0,
                          height: 16.0,
                          child: Checkbox(
                            value: false,
                            onChanged: (value) {},
                            activeColor: Colors.blue,
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        const SizedBox(width: 6.0),
                        Text(
                          'Rojo',
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(0xFF333333),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 16.0,
                          height: 16.0,
                          child: Checkbox(
                            value: false,
                            onChanged: (value) {},
                            activeColor: Colors.blue,
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        const SizedBox(width: 6.0),
                        Text(
                          'Amarillo',
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(0xFF333333),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 16.0,
                          height: 16.0,
                          child: Checkbox(
                            value: false,
                            onChanged: (value) {},
                            activeColor: Colors.blue,
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        const SizedBox(width: 6.0),
                        Text(
                          'Verde',
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(0xFF333333),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 16.0,
                          height: 16.0,
                          child: Checkbox(
                            value: false,
                            onChanged: (value) {},
                            activeColor: Colors.blue,
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        const SizedBox(width: 6.0),
                        Text(
                          'Checkbox 4',
                          style: TextStyle(
                            fontSize: 13.0,
                            color: Color(0xFF333333),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 82.0 * horizontalScale,
              top: 289.0 * verticalScale,
              child:               Container(
                width: 150.0 * horizontalScale,
                height: 150.0 * verticalScale,
                margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                decoration: BoxDecoration(
                  color: Color(0xFFFFFFFF),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                clipBehavior: Clip.antiAlias, // Ensure content is clipped to the rounded corners
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Optional header for the ListView (only shown if title is provided)
                    
                    Expanded(
                      child: Scrollbar(
                        thickness: 6.0,
                        radius: const Radius.circular(8.0),
                        thumbVisibility: true,
                        controller: _scrollController_component_1749674298760,
                        child: ListView(
                          controller: _scrollController_component_1749674298760,
                          scrollDirection: Axis.vertical,
                          physics: const BouncingScrollPhysics(), // iOS-like bouncing effect
                          padding: EdgeInsets.fromLTRB(8.0, 4.0, 8.0, 8.0),
                          children: [
                    Card(
                      elevation: 2.0,
                      margin: EdgeInsets.only(bottom: 4.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Container(
                        width: 150.0 * horizontalScale,
                        
                        constraints: BoxConstraints(
                          minWidth: 100.0,
                          minHeight: 20.0,
                        ),
                        padding: const EdgeInsets.all(12),
                        alignment: Alignment.center,
                        child: Text(
                          'Item 1',
                          style: const TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Card(
                      elevation: 2.0,
                      margin: EdgeInsets.only(bottom: 4.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Container(
                        width: 150.0 * horizontalScale,
                        
                        constraints: BoxConstraints(
                          minWidth: 100.0,
                          minHeight: 20.0,
                        ),
                        padding: const EdgeInsets.all(12),
                        alignment: Alignment.center,
                        child: Text(
                          'Item 2',
                          style: const TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Card(
                      elevation: 2.0,
                      margin: EdgeInsets.only(bottom: 4.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Container(
                        width: 150.0 * horizontalScale,
                        
                        constraints: BoxConstraints(
                          minWidth: 100.0,
                          minHeight: 20.0,
                        ),
                        padding: const EdgeInsets.all(12),
                        alignment: Alignment.center,
                        child: Text(
                          'Item 3',
                          style: const TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                    Card(
                      elevation: 2.0,
                      margin: EdgeInsets.only(bottom: 4.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Container(
                        width: 150.0 * horizontalScale,
                        
                        constraints: BoxConstraints(
                          minWidth: 100.0,
                          minHeight: 20.0,
                        ),
                        padding: const EdgeInsets.all(12),
                        alignment: Alignment.center,
                        child: Text(
                          'Item 4',
                          style: const TextStyle(fontWeight: FontWeight.w500),
                        ),
                      ),
                    ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
    );
  }
}