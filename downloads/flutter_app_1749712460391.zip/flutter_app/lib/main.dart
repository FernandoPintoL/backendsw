import 'package:flutter/material.dart';
import 'package:flutter_app/screens/vehiculoscreen.dart';
import 'package:flutter_app/screens/comprasscreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/vehiculoscreen',
      routes: {
        '/vehiculoscreen': (context) => const VehiculoScreen(),
        '/comprasscreen': (context) => const ComprasScreen(),
      },
    );
  }
}

// Navigation helper
class AppNavigation {
  static void navigateTo(BuildContext context, String routeName) {
    Navigator.pushNamed(context, routeName);
  }
}