import 'package:flutter/material.dart';

class ComprasScreen extends StatelessWidget {
  const ComprasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Get the device screen size
    final screenSize = MediaQuery.of(context).size;

    // Calculate scaling factors based on design dimensions (320x568)
    final horizontalScale = screenSize.width / 320.0;
    final verticalScale = screenSize.height / 568.0;


    return Scaffold(
      appBar: AppBar(
        title: Text('Compras'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Navigation',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
              ListTile(
                leading: Icon(Icons.screen_share),
                title: Text('Vehiculo'),
                onTap: () {
                  Navigator.pushNamed(context, '/vehiculoscreen');
                },
              ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: screenSize.width,
          height: screenSize.height - AppBar().preferredSize.height - MediaQuery.of(context).padding.top,
          child: Stack(
            children: [
            Positioned(
              left: 22.0 * horizontalScale,
              top: 22.0 * verticalScale,
              child:               Container(
                width: 280.0 * horizontalScale,
                height: 480.0 * verticalScale,
                padding: const EdgeInsets.all(10.0),
                decoration: BoxDecoration(
                  color: Color(0xFF62D723),
                  borderRadius: BorderRadius.circular(30.0),
                  border: Border.all(
                    color: Colors.blue,
                    width: 1.0,
                    style: BorderStyle.solid,
                  ),
                ),
                child: null,
              ),
            ),
          ],
        ),
      ),
    ),
    );
  }
}