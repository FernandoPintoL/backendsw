# Flutter App

A Flutter application generated from a whiteboard design.

## Getting Started

This project is a Flutter application that was automatically generated.

To run this application:

1. Make sure you have Flutter installed on your machine
2. Update the `android/local.properties` file with your Flutter SDK path and Android SDK path:
   ```
   flutter.sdk=/path/to/your/flutter/sdk
   sdk.dir=/path/to/your/android/sdk
   ```

   Note: The paths should use forward slashes (/) even on Windows.
3. Run `flutter pub get` to install dependencies
4. Run `flutter run` to start the application

This project uses Flutter's Android v2 embedding and requires JDK 21. The Gradle version has been set to 8.5.

For more information about Flutter, visit [flutter.dev](https://flutter.dev).
